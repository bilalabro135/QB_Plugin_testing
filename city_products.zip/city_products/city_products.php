<?php 
	/**
	 * Plugin Name: City products
	 * Author: Bilal Sohail.
	 * Description: This plugin is used to filter the products from database by location.
	 * Version: 1.0.0
	 * */
	if (!defined('ABSPATH')) {
		header("Location: /");
		die();
	}
	require_once(plugin_dir_path( __FILE__ ).'plugin_filteration.php');