<?php 
	$geo_locate = (unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$_SERVER['REMOTE_ADDR'])));
	if ($geo_locate['geoplugin_city']) {
		$GLOBALS['location'] = $geo_locate['geoplugin_city'];
	}else{
		$GLOBALS['location'] = NULL;
	}

	// Change the shop query
	function action_woocommerce_product_query( $q, $query ) 
	{
	    if ( is_shop() && isset( $GLOBALS['location'] ) ) {
		    $meta_query = $q->get( 'meta_query' );
		    if (($GLOBALS['location'] == 'Karachi') || ($GLOBALS['location'] == 'Lahore')) {
	        	// Settings
		        $key = 'location';
		        $value = $GLOBALS['location'];
			    $meta_query[] = array(
			        'key' => $key,
			        'value' => $value,
			        'compare' => '='
			    );
			}
		    
		    $q->set( 'meta_query', $meta_query );
		}
	}
	add_filter( 'woocommerce_product_query', 'action_woocommerce_product_query', 10, 2 );


	function modify_featured_products($query_args) 
	{
	    // Modify the $query_args array as per your requirements
	    // For example, you can add or remove arguments, change their values, etc.
	    if (isset( $GLOBALS['location'])) {
		    $location = $GLOBALS['location'];
		    if (($location == 'Karachi') || ($location == 'Lahore')) {
		    	$query_args['tax_query'] = array(
			        array(
			            'taxonomy' => 'product_tag',
			            'field'    => 'slug',
			            'terms'    => $location,
			        ),
			    );
		    }
		}

	    return $query_args;
	}

	add_filter('woocommerce_shortcode_products_query', 'modify_featured_products', 10, 1);

 ?>